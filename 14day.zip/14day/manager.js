//const Kitchen = require()
const readline = require('readline');
const menu = require("./menu");
const { log } = require("console");

let orderqueue = new Array()
let orderqueueJson = new Object();
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});
const pseudoPOS = {
    laundry: () => {
      // setInterval => 비동기적으로 수행하는 코드
      console.log('배달어플 돌리기 시작')
      let time = 250
  
      const intervalId = setInterval(() => {
        console.log(`${percentage}% 완료`)
        time += 250
  
        if (time === 1000) {
          clearInterval(intervalId)
          console.log(`${percentage}% 주문 완료`)
          resolve()
        }
      }, 1000)
    },
    dishes: () => console.log('준비된 쿡이 가져가기'),
    received: () => console.log('시간재기'),
  }
  


const order_receiving_daemon = () => {}
// 대기큐에 들어있는 이벤트를 꺼내서 
// 처리하는 이벤트 루퍼(Looper)를 별도 모듈/객체로 분리해서 구현한다.
// log(POS.Manager());
// }

// times.map((time) => parseInt(time))

async function newOrder(){

}
//setInterval(newOrder, 1000);
  //order_receiving_daemon()

//log(menu.LIST['1'][0])

const intervalId = setInterval(() => {
    log("1 sec passed")
    if(orderqueue.length > 0){ // & cook.state = 'ready'
        //log("주문 받았다!")
    }
    
    //if(bool == true){
      //clearInterval(intervalId),
    //   log("완료"),
    //   resolve())
    //}
    //log('fin')
  }, 1000)


exports.manage = function(){


  rl.on('line', (input) => {
    if(input.indexOf(':') != -1){
        const nextOrder = input.split(':') // input orderingFormat: '1 2 3'
        const orderingFormat = nextOrder.map((el) => el)
        /*
        console.log( 'orderingFormat[0]' in menu.LIST ) // true
        이 방법엔 단점이 있다.
        다음에서 처럼 Object의 프로토타입 체인으로 생성한 프로퍼티도 체크한다는 것이다.
        Object.prototype.test_2 = undefined

        Object.hasOwnProperty
        메소드는 객체가 특정 프로퍼티를 소유했는지를 반환한다. 
        특히 객체가 지정된 속성을 프로토타입 체인을 통해 상속되지 않은 그 객체의 
        직접 속성으로 포함하는지를 나타내는 boolean을 반환한다.

        menu.LIST.hasOwnProperty('orderingFormat[0]')
        */
        //let orderedMenu = orderingFormat[0]
        //orderqueueJson.menu.LIST['1'][0] = {burstTime : parseInt(menu.LIST['1'][0]), amount : parseInt(orderingFormat[1])}
        if(menu.LIST.hasOwnProperty(orderingFormat[0])){
            log("Correct formatted order is received")
            const newReceivement = {food : menu.LIST[orderingFormat[0]][0], burstTime : parseInt(menu.LIST[orderingFormat[0]][1]), amount : parseInt(orderingFormat[1])}
            orderqueue.push(newReceivement)
            log(orderqueue)
        }
        else{
            log("Incorrect formatted order is received. Make order again.")

        }
        // console.clear()
    }
    //rl.close(input);
})

}

// module.exports = {manager}

