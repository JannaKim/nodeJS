const { log } = require("console");
const manager = require('./manager.js');
class RestaurantBusiness {
    constructor (nmChef, nmDeliveryMen, deadline)  {
      this.nmChef = 0;
      this.nmDeliveryMen = 0;
      this.deadline = 0;

      this.setPolicy(nmChef, nmDeliveryMen, deadline)

      this.Manager = manager.manage();
      //Manager();
    }
    
    setPolicy(nmChef, nmDeliveryMen, deadline) {
      this.nmChef = nmChef;
      this.nmDeliveryMen = nmDeliveryMen;
      this.deadline = deadline;
    }
  }
  

const Singleton = {
    instance: null,
    
    storeOpening(nmChef, nmDeliveryMen, deadline) {
      if(!this.instance)
        this.instance = new RestaurantBusiness(nmChef, nmDeliveryMen, deadline);
      
      return this.instance;
    }
  }
  

  // let restaurantBusiness = Singleton.storeOpening(4, 2, 3);
  // let restaurantBusiness2 = Singleton.storeOpening(3, 1, 2);
  // let restaurantBusiness3 = Singleton.storeOpening(2, 1, 0);
  
  // console.log(restaurantBusiness.nmChef, restaurantBusiness2.nmChef, restaurantBusiness3.nmChef); // 4 4 4
  // restaurantBusiness2.setPolicy(10, 10, 10);
  // console.log(restaurantBusiness.nmChef, restaurantBusiness2.nmChef, restaurantBusiness3.nmChef); // 10 10 10

 module.exports = {Singleton}