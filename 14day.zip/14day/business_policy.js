const businessPolicy = {
    nmChef : 0,
    nmDeliveryMen : 0,
    deadline : false
};

module.exports = {businessPolicy}