
// 클래스를 가져가긴 해도 객체를 옮겨다녀아 하는데?

// let exports = module.exports = {};
class Kichen{
    _a;
    constructor(v){
        this._a = v;
    }
    get a(){
        return this._a;
    }

}

let K1 = new Kichen(1)
let K2 = new Kichen(2)

module.exports = {K1, K2}