enum State {
    runnable = "runnable",
    running = "running",
    waiting = "waiting",
    blocked = "blocked",
    terminated = "terminated",
  }

  running 명령어들이 실행중
  waiting 프로세스가 어떤 사건이 일어나기를 기다림
  입출작업이 완료를 기다리는 것 같은 특별한 사건을 기다림

/*
상태 열거 상수 설명

객체 생성	NEW	스레드 객체가 생성, 아직 start() 메소드가 호출되지 않은 상태
실행 대기	RUNNABLE	실행 상태로 언제든지 갈 수 있는 상태
일시 정지	WAITING	다른 스레드가 통지할 때까지 기다리는 상태
TIMED_WAITING	주어진 시간 동안 기다리는 상태
BLOCKED	사용하고자 하는 객체의 락이 풀릴 때까지 기다리는 상태
종료	TERMINATED	실행을 마친 상태

출처: https://widevery.tistory.com/27 [Everything]
*/ 