const { restaurantBusiness } = require("./opening");

class Employee{
    name;
    job;
    ability;

    constructor(name, job, limit){
        this.name = name
        this.job = job
        this.ability = new Array(limit) // 안에 요리 객체
        for(let i = 0; i < limit; ++i)
            this.ability[i] = null
            
    }

    work = () => {
        for(let i = 0; i < limit; ++i){ // 가진 능역만큼 요리나 배달
            if(this.ability[i] === null) continue
            ability[i].prop[job]-- //요리 남은 시간 - 1
            // 해당 요리 끝 = 고객 요리 left - 1 요리 객체가 한다.
                // restaurantBusiness.Queue.emit('event');  
        }
    }

    idle = () => {

    }


}

module.exports = { Employee : Employee }