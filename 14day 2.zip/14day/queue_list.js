module.exports = {
    queue : { //요리 객체 리스트
        'cooking' : [],
        'waiting orders' : [],
        'waiting for delivery' : [],
        'in delivery' : []
    },
}